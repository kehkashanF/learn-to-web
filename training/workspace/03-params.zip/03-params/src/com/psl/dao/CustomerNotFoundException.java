package com.psl.dao;



public class CustomerNotFoundException extends RuntimeException {
		
}
