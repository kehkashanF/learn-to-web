package com.psl.service;


import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.PathSegment;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import com.psl.bean.Customer;
import com.psl.dao.CustomerDAO;
import com.psl.dao.CustomerNotFoundException;


@Path("/")
public class CustomerService {
	
			@Context
			private UriInfo uriinfo;
			
			@Context
			private HttpHeaders headers;
			
			@GET
			@Path("/fetch")
			@Produces(value=MediaType.TEXT_PLAIN)
			
			public String getCustomerByIdQueryParams(@QueryParam("id") int customerId, @Context UriInfo uriinfo) {
				
				Customer customer=new CustomerDAO().getCustomerById(customerId);
				return customer.toString();
				
			}
			
		
			
			@GET
			@Path("/fetch3/{id}") //{id} <-- template parameter
			@Produces(value=MediaType.TEXT_PLAIN )
			public String getCustomerByIdPathParams(@PathParam("id") int customerId) {
				
				Customer customer=new CustomerDAO().getCustomerById(customerId);
					return customer.toString();
			}
			
			
			@GET
			@Path("/fetch/{id}")
			@Produces(value={MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
			public Response getCustomerById(@PathParam("id")int customerId) {
				Customer customer=new CustomerDAO().getCustomerById(customerId);
				return Response.ok(customer).build();
				
			}
			
			
			@POST
			@Path("/new")
			@Consumes(value={MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
			public Response createCustomer(Customer customer){
				new CustomerDAO().save(customer);
				return Response.status(Status.CREATED).build();
			}
			
			
			@POST
			@Path("/update/{id}")
			public void updateCustomer(@PathParam("id") int customerId, 
									@DefaultValue("--no name--") @FormParam("fn") String firstName, 
									@DefaultValue("--no name--") @FormParam("ln") String lastName){
				Customer customer=new Customer(customerId, firstName, lastName);
				new CustomerDAO().update(customer);
				
			}
			
			
			
			
			@GET
			@Path("/delete/{id}")
			public void deleteCustomer(@PathParam("id") int customerId){
				//Customer customer=new CustomerDAO().getCustomerById(customerId);
				new CustomerDAO().delete(customerId);
			}
			
			
			//http://localhost:8181/03-params/fetch1/11;mark=true;show=false/12;mark=true;show=true/13;mark=false;show=true
//			@GET
//			@Path("/fetch1/{id:.+}")
//			public void markCustomers(@PathParam("id") List<PathSegment> segments)
//			{
//				for(PathSegment segment:segments){
//					System.out.println(segment.getPath());
//					System.out.println(segment.getMatrixParameters().get("mark"));
//					System.out.println(segment.getMatrixParameters().get("show"));
//				}
//			}
}
