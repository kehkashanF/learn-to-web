package com.psl.pojo;

public class Student {
	private int rollNo;
	private String name;
	private int std;
	
	public Student() {

	}
	
	
}
