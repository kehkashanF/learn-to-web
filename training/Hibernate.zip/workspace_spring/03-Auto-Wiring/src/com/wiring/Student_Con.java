package com.wiring;

public class Student_Con {
	private Address address;

	public Student_Con(Address address) {
		super();
		this.address = address;
	}

	public String toString() {
		return "Student_Con [address=" + address + "]";
	}
	
	
}
