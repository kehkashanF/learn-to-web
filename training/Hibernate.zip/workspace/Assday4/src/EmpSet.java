import java.util.Set;
import java.util.TreeSet;


public class EmpSet {
	public void addInput(){}
	public void display(){}
	public static void main(String[] args) {
			Set<Employye> set=new TreeSet<Employye>();
			
	}
}
