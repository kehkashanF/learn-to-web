
public class LenPalString {
	public static void main(String[] args) {
		int length;
		 length=args[0].length();
		 System.out.println("Length of string is "+length);
		 
	}
}
