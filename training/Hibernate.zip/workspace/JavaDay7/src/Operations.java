
public interface Operations {
		public int operations(int a, int b);
}
