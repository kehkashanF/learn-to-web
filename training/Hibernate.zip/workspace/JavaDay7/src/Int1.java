
public interface Int1 {
		 public default void m1(){
			 	System.out.println("IntA");
		}
}
