
public interface Greeting {
		public void greet(String name);
}
