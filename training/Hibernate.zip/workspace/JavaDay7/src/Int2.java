
public interface Int2 {
		public default void m1(){
			System.out.println("Int2");
		}
}
