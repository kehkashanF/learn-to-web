package com.mypackage;

public class Class2{
	public void m3(){
		System.out.println("M3");
	}
	
	public void m4(){
		System.out.println("M4");
	}
}