package com.mypackage;

public class Class1{
	public void m1(){
		System.out.println("M1");
	}
	
	void m2(){
		System.out.println("M2");
	}
}