package com.bean;

public enum Status {
	pending, approved, rejected, dispatched, delivered
}
