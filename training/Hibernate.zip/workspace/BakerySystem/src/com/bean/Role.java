package com.bean;

public enum Role {
			Admin, Customer;
}
