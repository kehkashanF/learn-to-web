package com.bean;

public enum delOption {

	HomeDelivery, Pickup ;
}
