
package com.exceptions;
 
public class ValidateException extends Exception{
 
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public ValidateException(String msg)
{
System.out.println(msg);
}
}
