
public class Term {
	private int coefficient;
	private int exponent;
	static int count;
	public Term() {
		
		coefficient=0;
		exponent=0;
	}
	public int getCoefficient() {
		return coefficient;
	}
	public void setCoefficient(int coefficient) {
		this.coefficient = coefficient;
	}
	public int getExponent() {
		return exponent;
	}
	public void setExponent(int exponent) {
		this.exponent = exponent;
	}
	
	
}


