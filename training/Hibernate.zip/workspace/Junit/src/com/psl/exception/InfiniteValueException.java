package com.psl.exception;

public class InfiniteValueException extends Exception{

}
