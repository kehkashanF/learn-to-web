package com.psl.exception;

public class InvalidInputException extends Exception {

}
