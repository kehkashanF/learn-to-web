package polymorphism;

public interface Zoo {
		public void Cage();
		public void FoodTime();
}
