package polymorphism;

public class Rectangle extends Shape {

	@Override
	public void calcArea(double b, double l) {
	
		area=l*b;
	}

}
