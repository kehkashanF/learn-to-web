package polymorphism;

public class Triangle extends Shape {

	@Override
	public void calcArea(double b, double l) {
		// TODO Auto-generated method stub
		area=l*b*0.5;
		
	}

}
