
public class NegativeAmount extends Exception{
		public NegativeAmount(String msg) {
			System.out.println(msg);
		}
}
