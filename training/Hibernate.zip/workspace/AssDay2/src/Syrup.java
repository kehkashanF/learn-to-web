
public class Syrup extends Medicine{

	@Override
	public void displayLabel() {
		super.displayLabel();
		System.out.println("Syrup: Dosage as given by doctor");
	}

}
