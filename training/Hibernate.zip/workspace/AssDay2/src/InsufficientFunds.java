
public class InsufficientFunds extends Exception{
		public InsufficientFunds(String msg) {
			System.out.println(msg);
		}
}
