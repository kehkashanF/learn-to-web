
public class Ointment extends Medicine {

	@Override
	public void displayLabel() {
		super.displayLabel();
		System.out.println("Ointment: for external use only");
	}

}
