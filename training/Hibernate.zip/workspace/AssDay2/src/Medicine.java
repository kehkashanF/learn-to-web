
public class Medicine {
	
	public void displayLabel(){
		System.out.println("Name: Unilever\nAddress: Mumbai");
	}
}
